# Overview
Python code for a car sim <br/>
Moving_car: Code that simulates a self-driving car, aiming to travel along a line of cones <br/>
coneconnecting: Code that holds math for finding cones that 'connect' to form the track boundry <br/>
