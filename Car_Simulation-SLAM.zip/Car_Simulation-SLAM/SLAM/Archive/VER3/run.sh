#!/bin/bash

python host.py &
python main.py &
python main2.py &