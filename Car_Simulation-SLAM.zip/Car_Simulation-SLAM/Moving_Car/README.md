### README <br/>

To run moving_car_splines.py you will need the following images:<br/>
car_r_30.png <br/>
target_r_t.png <br/>
target_g_t.png <br/>
left_cone_s.png <br/>
right_cone_s.png <br/>
left_spline_s.png <br/>
right_spline_s.png <br/>
<br/>
To run moving_car_splines.py or moving_car.py you will need the following python packages:<br/>
os <br/>
pygame <br/>
math <br/>
time <br/>
numpy <br/>
cv2 <br/>
PIL <br/>
scipy <br/>
<br/>
To run moving_car.py you will need the following images:<br/>
car_r_s.png <br/>
target_s.png <br/>
target_sg.png <br/>
<br/>
